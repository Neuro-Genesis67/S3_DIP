const messages = [
    {
        id: 1,
        msg: 'Besked 1',
    },
    {
        id: 2,
        msg: 'Besked 2',
    }, 
    {
        id: 3,
        name: 'Besked 3',
    },  
    
];

module.exports = messages;




