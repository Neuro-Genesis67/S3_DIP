// callback.js
function callback(){console.log('... called!');}
setTimeout(callback, 1000);
// => ... called!
